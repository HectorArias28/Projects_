class Person < ApplicationRecord
end
