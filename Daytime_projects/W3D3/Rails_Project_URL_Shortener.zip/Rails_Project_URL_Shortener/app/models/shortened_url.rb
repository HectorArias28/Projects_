class ShortenedUrl < ApplicationRecord
end