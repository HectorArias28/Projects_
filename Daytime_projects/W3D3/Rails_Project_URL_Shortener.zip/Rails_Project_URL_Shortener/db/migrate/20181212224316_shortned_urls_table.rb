class ShortnedUrlsTable < ActiveRecord::Migration[5.2]
  def change
    create_table :shortened_url do |t|
      t.text :long_url
      t.text :short_url
    end
  end
end
