class CreateUsers < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.text :email
      # t.integer :email_index
      t.timestamps
    end
  end
end
