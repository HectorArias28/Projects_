# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
ActiveRecord::Base.transaction do
  User.destroy_all
  Poll.destroy_all
  Question.destroy_all
  AnswerChoice.destroy_all
  Response.destroy_all

    u1 = User.create!(user_name: 'harias')
    u2 = User.create!(user_name: 'lizzy')
    u3 = User.create!(user_name: 'johnny')
    u4 = User.create!(user_name: 'anthony')
    u5 = User.create!(user_name: 'joe')
    u6 = User.create!(user_name: 'james')


    p1 = Poll.create!(title: 'icecream', author: u1)
    p2 = Poll.create!(title: 'favorite food', author: u2)
    p3 = Poll.create!(title: 'favorite season', author: u3)
    p4 = Poll.create!(title: 'best vacation destination', author: u4)


    q1 = Question.create!(text: 'What''s your favorite icecream?', poll: p1)
    q2 = Question.create!(text: 'What''s your favorite food?', poll: p2)
    q3 = Question.create!(text: 'What''s your favorite season?', poll: p3)
    q4 = Question.create!(text: 'What''s the best vacation spot?', poll: p4)

    a1 = AnswerChoice.create!(text: 'vanilla', question: q1)
    a2 = AnswerChoice.create!(text: 'chocolate', question: q1)
    a3 = AnswerChoice.create!(text: 'pizza', question: q2)
    a4 = AnswerChoice.create!(text: 'burgers', question: q2)
    a5 = AnswerChoice.create!(text: 'summer', question: q3)
    a6 = AnswerChoice.create!(text: 'spring', question: q3)
    a7 = AnswerChoice.create!(text: 'bahamas', question: q4)
    a8 = AnswerChoice.create!(text: 'costa rica', question: q4)

    r1 = Response.create!(answer_choice: a1, respondent: u3)
    r2 = Response.create!(answer_choice: a2, respondent: u4)
    r3 = Response.create!(answer_choice: a3, respondent: u5)
    r4 = Response.create!(answer_choice: a4, respondent: u6)
    r5 = Response.create!(answer_choice: a5, respondent: u1)
    r6 = Response.create!(answer_choice: a6, respondent: u2)
    r7 = Response.create!(answer_choice: a7, respondent: u4)
    r8 = Response.create!(answer_choice: a8, respondent: u3)
end