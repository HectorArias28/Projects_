class Response < ApplicationRecord
    validates :not_duplicate_response, unless: -> { answer_choice.nil? }
    belongs_to :answer_choice,
        class_name: 'AnswerChoice',
        primary_key: :id,
        foreign_key: :answer_id

    belongs_to :respondent,
        class_name: 'User',
        primary_key: :id,
        foreign_key: :user_id

    has_one :question,
        through: :answer_choice, 
        source: :question 


    def sibling_responses
       self.question.responses.where('responses.id != ?' , self.id)
    end

    def respondent_already_answered?
        self.sibling_responses.where('responses.user_id = ?', self.user_id).pluck(:id).length > 0
    end


private

  def not_duplicate_response
    if respondent_already_answered?
      errors[:respondent_id] << 'respondent already answered'
    end
  end
end